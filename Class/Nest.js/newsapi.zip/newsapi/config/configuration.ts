/* eslint-disable prettier/prettier */
export default () => ({
  newsApiKey: process.env.NEWS_API_KEY,
});
